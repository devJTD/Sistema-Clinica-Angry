package com.clinica.sistema.Configuracion;

public class SeguridadConfiguracion {
    
}
