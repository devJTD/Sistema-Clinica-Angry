package com.clinica.sistema.Repositorio;

public class MedicoRepositorio {
    
}
