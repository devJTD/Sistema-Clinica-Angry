package com.clinica.sistema.Servicio;

public class NotificacionServicio {
    
}
